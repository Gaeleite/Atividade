package com.example.campeonato.dto;

import lombok.Data;

@Data
public class TimeDTO {
    private Integer id;
    private String nome;
}
