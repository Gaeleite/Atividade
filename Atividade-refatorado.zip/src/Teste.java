import lombok.Data;

@Data
public class Teste {
    private String nome;
}
