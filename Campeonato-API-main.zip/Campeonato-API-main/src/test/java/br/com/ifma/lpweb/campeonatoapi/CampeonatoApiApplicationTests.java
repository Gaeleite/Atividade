package br.com.ifma.lpweb.campeonatoapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampeonatoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
