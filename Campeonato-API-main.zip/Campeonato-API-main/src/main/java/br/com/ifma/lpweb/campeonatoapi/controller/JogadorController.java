package br.com.ifma.lpweb.campeonatoapi.controller;

import br.com.ifma.lpweb.campeonatoapi.dto.JogadorCreateUpdateDTO;
import br.com.ifma.lpweb.campeonatoapi.dto.JogadorDTO;
import br.com.ifma.lpweb.campeonatoapi.model.Jogador;
import br.com.ifma.lpweb.campeonatoapi.service.JogadorService;
import jakarta.validation.Valid;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;

@RestController
@RequestMapping("/jogadores")
public class JogadorController {

 @Autowired
 private JogadorService jogadorService;

 @Autowired
 private ModelMapper modelMapper;

 @GetMapping
 public ResponseEntity<Page<JogadorDTO>> listarTodos(Pageable pageable) {
     Page<Jogador> jogadoresPage = jogadorService.listarTodos(pageable);
     Page<JogadorDTO> jogadorDTOPage = jogadoresPage.map(this::convertToDto);
     return ResponseEntity.ok(jogadorDTOPage);
 }

 @GetMapping("/{id}")
 public ResponseEntity<JogadorDTO> buscarPorId(@PathVariable Integer id) {
     return jogadorService.buscarPorId(id)
             .map(jogador -> ResponseEntity.ok(convertToDto(jogador)))
             .orElse(ResponseEntity.notFound().build());
 }

 @PostMapping
 public ResponseEntity<JogadorDTO> criar(@Valid @RequestBody JogadorCreateUpdateDTO jogadorDTO) {
     Jogador jogadorSalvo = jogadorService.salvar(jogadorDTO);
     URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
             .buildAndExpand(jogadorSalvo.getId()).toUri();
     return ResponseEntity.created(location).body(convertToDto(jogadorSalvo));
 }

 @PutMapping("/{id}")
 public ResponseEntity<JogadorDTO> atualizar(@PathVariable Integer id, @Valid @RequestBody JogadorCreateUpdateDTO jogadorDTO) {
     Jogador jogadorAtualizado = jogadorService.atualizar(id, jogadorDTO);
     return ResponseEntity.ok(convertToDto(jogadorAtualizado));
 }

 @DeleteMapping("/{id}")
 public ResponseEntity<Void> remover(@PathVariable Integer id) {
     jogadorService.deletar(id);
     return ResponseEntity.noContent().build();
 }

 private JogadorDTO convertToDto(Jogador jogador) {
     JogadorDTO dto = modelMapper.map(jogador, JogadorDTO.class);
     if (jogador.getTimeEmQueJoga() != null) {
         dto.setTimeId(jogador.getTimeEmQueJoga().getId());
         dto.setNomeTime(jogador.getTimeEmQueJoga().getNome());
     }
     return dto;
 }
}
