package br.com.ifma.lpweb.campeonatoapi.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class EstadioCreateUpdateDTO {

 @NotBlank(message = "O nome não pode ser vazio.")
 @Size(min = 3, max = 100, message = "O nome deve ter entre 3 e 100 caracteres.")
 private String nome;

 @NotBlank(message = "O endereço não pode ser vazio.")
 private String endereco;

 // Getters e Setters
 public String getNome() { return nome; }
 public void setNome(String nome) { this.nome = nome; }
 public String getEndereco() { return endereco; }
 public void setEndereco(String endereco) { this.endereco = endereco; }
}
