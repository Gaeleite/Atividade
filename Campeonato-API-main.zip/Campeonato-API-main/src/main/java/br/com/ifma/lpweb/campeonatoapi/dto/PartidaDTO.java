package br.com.ifma.lpweb.campeonatoapi.dto;

import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PartidaDTO {
 private Integer id;
 private LocalDate data;
 private String nomeCampeonato;
 private TimeDTO timeMandante;
 private TimeDTO timeVisitante;
 private EstadioDTO estadio;
 private ResultadoDTO resultado;
}
