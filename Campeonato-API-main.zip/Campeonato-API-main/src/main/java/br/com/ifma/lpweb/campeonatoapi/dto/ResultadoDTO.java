package br.com.ifma.lpweb.campeonatoapi.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResultadoDTO {
 private Integer numGolsMandante;
 private Integer numGolsVisitante;
}
