package br.com.ifma.lpweb.campeonatoapi.dto;

import java.util.Set;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CampeonatoCreateDTO {

 @NotBlank
 private String nome;

 @NotNull
 private Integer ano;

 private Set<Integer> timesIds; // Apenas os IDs dos times para associar

}
