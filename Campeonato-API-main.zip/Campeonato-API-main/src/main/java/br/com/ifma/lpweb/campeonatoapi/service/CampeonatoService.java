package br.com.ifma.lpweb.campeonatoapi.service;

import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.ifma.lpweb.campeonatoapi.dto.CampeonatoCreateDTO;
import br.com.ifma.lpweb.campeonatoapi.dto.TabelaCampeonatoDTO;
import br.com.ifma.lpweb.campeonatoapi.model.Campeonato;
import br.com.ifma.lpweb.campeonatoapi.model.Partida;
import br.com.ifma.lpweb.campeonatoapi.model.Time;
import br.com.ifma.lpweb.campeonatoapi.repository.CampeonatoRepository;
import br.com.ifma.lpweb.campeonatoapi.repository.PartidaRepository;
import br.com.ifma.lpweb.campeonatoapi.repository.TimeRepository;
import jakarta.persistence.EntityNotFoundException;

@Service
public class CampeonatoService {

 @Autowired
 private CampeonatoRepository campeonatoRepository;
 @Autowired
 private PartidaRepository partidaRepository; // Não esqueça de injetar


 @Autowired
 private TimeRepository timeRepository;

 @Transactional
 public Campeonato salvar(CampeonatoCreateDTO dto) {
     Campeonato campeonato = new Campeonato();
     campeonato.setNome(dto.getNome());
     campeonato.setAno(dto.getAno());

     if (dto.getTimesIds() != null && !dto.getTimesIds().isEmpty()) {
         Set<Time> times = new HashSet<>(timeRepository.findAllById(dto.getTimesIds()));
         campeonato.setTimes(times);
     }

     return campeonatoRepository.save(campeonato);
 }
 
 public List<Campeonato> listarTodos() {
     return campeonatoRepository.findAll();
 }

 public Optional<Campeonato> buscarPorId(Integer id) {
     return campeonatoRepository.findById(id);
 }

 // Método para a funcionalidade específica 
 public Set<Time> listarTimesDoCampeonato(Integer id) {
     Campeonato campeonato = campeonatoRepository.findById(id)
             .orElseThrow(() -> new EntityNotFoundException("Campeonato não encontrado com id: " + id));
     return campeonato.getTimes();
 }
 
 public List<TabelaCampeonatoDTO> gerarTabela(Integer campeonatoId) {
     Campeonato campeonato = campeonatoRepository.findById(campeonatoId)
             .orElseThrow(() -> new EntityNotFoundException("Campeonato não encontrado com id: " + campeonatoId));

     List<Partida> partidasFinalizadas = partidaRepository.findByCampeonatoIdAndResultadoIsNotNull(campeonatoId);

     // 1. Cria um mapa para armazenar as estatísticas de cada time
     Map<String, TabelaCampeonatoDTO> estatisticas = new HashMap<>();
     for (Time time : campeonato.getTimes()) {
         estatisticas.put(time.getNome(), new TabelaCampeonatoDTO(time.getNome()));
     }

     // 2. Itera sobre cada partida finalizada para calcular as estatísticas
     for (Partida partida : partidasFinalizadas) {
         TabelaCampeonatoDTO statsMandante = estatisticas.get(partida.getTimeMandante().getNome());
         TabelaCampeonatoDTO statsVisitante = estatisticas.get(partida.getTimeVisitante().getNome());
         
         int golsMandante = partida.getResultado().getNumGolsMandante();
         int golsVisitante = partida.getResultado().getNumGolsVisitante();

         // Atualiza jogos, gols pro e gols contra
         statsMandante.setJogos(statsMandante.getJogos() + 1);
         statsVisitante.setJogos(statsVisitante.getJogos() + 1);
         statsMandante.setGolsPro(statsMandante.getGolsPro() + golsMandante);
         statsVisitante.setGolsPro(statsVisitante.getGolsPro() + golsVisitante);
         statsMandante.setGolsContra(statsMandante.getGolsContra() + golsVisitante);
         statsVisitante.setGolsContra(statsVisitante.getGolsContra() + golsMandante);

         // Atualiza pontos, vitórias, empates e derrotas
         if (golsMandante > golsVisitante) { // Mandante venceu
             statsMandante.setPontos(statsMandante.getPontos() + 3);
             statsMandante.setVitorias(statsMandante.getVitorias() + 1);
             statsVisitante.setDerrotas(statsVisitante.getDerrotas() + 1);
         } else if (golsVisitante > golsMandante) { // Visitante venceu
             statsVisitante.setPontos(statsVisitante.getPontos() + 3);
             statsVisitante.setVitorias(statsVisitante.getVitorias() + 1);
             statsMandante.setDerrotas(statsMandante.getDerrotas() + 1);
         } else { // Empate
             statsMandante.setPontos(statsMandante.getPontos() + 1);
             statsVisitante.setPontos(statsVisitante.getPontos() + 1);
             statsMandante.setEmpates(statsMandante.getEmpates() + 1);
             statsVisitante.setEmpates(statsVisitante.getEmpates() + 1);
         }
     }

     // 3. Calcula o saldo de gols para cada time
     estatisticas.values().forEach(stats -> 
         stats.setSaldoDeGols(stats.getGolsPro() - stats.getGolsContra())
     );

     // 4. Ordena a lista de acordo com os critérios do desafio
     return estatisticas.values().stream()
             .sorted(Comparator.comparing(TabelaCampeonatoDTO::getVitorias)
                               .thenComparing(TabelaCampeonatoDTO::getSaldoDeGols).reversed())
             .collect(Collectors.toList());
 }
}