package br.com.ifma.lpweb.campeonatoapi.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Positive;
import java.time.LocalDate;

public class JogadorCreateUpdateDTO {

 @NotBlank(message = "O nome não pode ser vazio.")
 private String nome;

 @NotNull(message = "A data de nascimento é obrigatória.")
 @Past(message = "A data de nascimento deve ser no passado.")
 private LocalDate nascimento;

 @NotNull(message = "A altura é obrigatória.")
 @Positive(message = "A altura deve ser um valor positivo.")
 private Float altura;

 private String genero;

 @NotNull(message = "O ID do time é obrigatório.")
 private Integer timeId;

 // Getters e Setters
 public String getNome() { return nome; }
 public void setNome(String nome) { this.nome = nome; }
 public LocalDate getNascimento() { return nascimento; }
 public void setNascimento(LocalDate nascimento) { this.nascimento = nascimento; }
 public Float getAltura() { return altura; }
 public void setAltura(Float altura) { this.altura = altura; }
 public String getGenero() { return genero; }
 public void setGenero(String genero) { this.genero = genero; }
 public Integer getTimeId() { return timeId; }
 public void setTimeId(Integer timeId) { this.timeId = timeId; }
}