package br.com.ifma.lpweb.campeonatoapi.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
// Usar a anotação Transactional do próprio Spring
import org.springframework.transaction.annotation.Transactional;

import br.com.ifma.lpweb.campeonatoapi.dto.PartidaCreateDTO;
import br.com.ifma.lpweb.campeonatoapi.dto.ResultadoCreateDTO;
import br.com.ifma.lpweb.campeonatoapi.model.Campeonato;
import br.com.ifma.lpweb.campeonatoapi.model.Estadio;
import br.com.ifma.lpweb.campeonatoapi.model.Partida;
import br.com.ifma.lpweb.campeonatoapi.model.Resultado;
import br.com.ifma.lpweb.campeonatoapi.model.Time;
import br.com.ifma.lpweb.campeonatoapi.repository.CampeonatoRepository;
import br.com.ifma.lpweb.campeonatoapi.repository.EstadioRepository;
import br.com.ifma.lpweb.campeonatoapi.repository.PartidaRepository;
import br.com.ifma.lpweb.campeonatoapi.repository.TimeRepository;
import jakarta.persistence.EntityNotFoundException;

@Service
public class PartidaService {

    @Autowired
    private PartidaRepository partidaRepository;
    @Autowired
    private CampeonatoRepository campeonatoRepository;
    @Autowired
    private TimeRepository timeRepository;
    @Autowired
    private EstadioRepository estadioRepository;

    @Transactional
    public Partida salvar(PartidaCreateDTO dto) {
        // 1. Busca as entidades relacionadas, como antes
        Campeonato camp = campeonatoRepository.findById(dto.getCampeonatoId())
                .orElseThrow(() -> new EntityNotFoundException("Campeonato não encontrado com id: " + dto.getCampeonatoId()));
        
        Time mandante = timeRepository.findById(dto.getTimeMandanteId())
                .orElseThrow(() -> new EntityNotFoundException("Time mandante não encontrado com id: " + dto.getTimeMandanteId()));

        Time visitante = timeRepository.findById(dto.getTimeVisitanteId())
                .orElseThrow(() -> new EntityNotFoundException("Time visitante não encontrado com id: " + dto.getTimeVisitanteId()));
        
        Estadio estadio = estadioRepository.findById(dto.getEstadioId())
                .orElseThrow(() -> new EntityNotFoundException("Estádio não encontrado com id: " + dto.getEstadioId()));

        // 2. NOVA VALIDAÇÃO - AQUI ESTÁ A CORREÇÃO
        // Verifica se o time mandante está na lista de times do campeonato
        if (!camp.getTimes().contains(mandante)) {
            throw new IllegalArgumentException("O time mandante '" + mandante.getNome() + "' não participa do campeonato '" + camp.getNome() + "'.");
        }

        // Verifica se o time visitante está na lista de times do campeonato
        if (!camp.getTimes().contains(visitante)) {
            throw new IllegalArgumentException("O time visitante '" + visitante.getNome() + "' não participa do campeonato '" + camp.getNome() + "'.");
        }

        // 3. Se a validação passar, cria e salva a partida
        Partida partida = new Partida();
        partida.setData(dto.getData());
        partida.setCampeonato(camp);
        partida.setTimeMandante(mandante);
        partida.setTimeVisitante(visitante);
        partida.setEstadio(estadio);

        return partidaRepository.save(partida);
    }

    @Transactional
    public Partida adicionarResultado(Integer partidaId, ResultadoCreateDTO dto) {
        Partida partida = partidaRepository.findById(partidaId)
                .orElseThrow(() -> new EntityNotFoundException("Partida não encontrada com id: " + partidaId));
        
        // Evita adicionar um resultado a uma partida que já tem um
        if (partida.getResultado() != null) {
            throw new IllegalStateException("Esta partida já possui um resultado.");
        }
        
        Resultado resultado = new Resultado();
        resultado.setNumGolsMandante(dto.getNumGolsMandante());
        resultado.setNumGolsVisitante(dto.getNumGolsVisitante());
        resultado.setPartida(partida);
        
        partida.setResultado(resultado);
        return partidaRepository.save(partida);
    }
    
    // Nenhuma alteração necessária aqui
    public List<Partida> listarOcorridas() {
        return partidaRepository.findByDataBefore(LocalDate.now());
    }

    // Nenhuma alteração necessária aqui
    public List<Partida> listarNaoOcorridas() {
        LocalDate hoje = LocalDate.now();
        return partidaRepository.findByDataAfterOrDataEquals(hoje, hoje);
    }

    // Nenhuma alteração necessária aqui
    public Optional<Partida> buscarPorId(Integer id) {
        return partidaRepository.findById(id);
    }
}