package br.com.ifma.lpweb.campeonatoapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;

@SpringBootApplication
@OpenAPIDefinition(info = @Info(
    title = "API de Campeonato de Futebol", 
    version = "1.0", 
    description = "API REST para gerenciamento de campeonatos de futebol, times, jogadores e partidas."
))
public class CampeonatoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CampeonatoApiApplication.class, args);
	}

}
