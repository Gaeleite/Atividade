package br.com.ifma.lpweb.campeonatoapi.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TimeCreateDTO {
    @NotBlank
    private String nome;

    @NotNull
    private Integer estadioId;

}
