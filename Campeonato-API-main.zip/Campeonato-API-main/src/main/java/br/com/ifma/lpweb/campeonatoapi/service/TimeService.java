package br.com.ifma.lpweb.campeonatoapi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.ifma.lpweb.campeonatoapi.dto.TimeCreateDTO;
import br.com.ifma.lpweb.campeonatoapi.model.Estadio;
import br.com.ifma.lpweb.campeonatoapi.model.Time;
import br.com.ifma.lpweb.campeonatoapi.repository.EstadioRepository;
import br.com.ifma.lpweb.campeonatoapi.repository.TimeRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;

@Service
public class TimeService {

    @Autowired
    private TimeRepository timeRepository;

    // 1. Injetar o repositório de estádios
    @Autowired
    private EstadioRepository estadioRepository;

    public List<Time> listarTodos() {
        return timeRepository.findAll();
    }

    public Optional<Time> buscarPorId(Integer id) {
        return timeRepository.findById(id);
    }

    // 2. Método salvar corrigido para usar o DTO
    @Transactional
    public Time salvar(TimeCreateDTO dto) {
        // Busca o estádio-sede pelo ID fornecido no DTO
        Estadio estadioSede = estadioRepository.findById(dto.getEstadioId())
                .orElseThrow(() -> new EntityNotFoundException("Estádio-sede não encontrado com id: " + dto.getEstadioId()));

        Time time = new Time();
        time.setNome(dto.getNome());
        time.setSede(estadioSede); // Associa o estádio encontrado ao time

        return timeRepository.save(time);
    }

    // 3. Método atualizar também ajustado para usar o DTO
    @Transactional
    public Time atualizar(Integer id, TimeCreateDTO dto) {
        Time time = timeRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Time não encontrado com id: " + id));

        Estadio novoEstadioSede = estadioRepository.findById(dto.getEstadioId())
                .orElseThrow(() -> new EntityNotFoundException("Estádio-sede não encontrado com id: " + dto.getEstadioId()));

        time.setNome(dto.getNome());
        time.setSede(novoEstadioSede);
        
        return timeRepository.save(time);
    }

    @Transactional
    public void deletar(Integer id) {
        if (!timeRepository.existsById(id)) {
            throw new EntityNotFoundException("Time não encontrado com id: " + id);
        }
        timeRepository.deleteById(id);
    }
}