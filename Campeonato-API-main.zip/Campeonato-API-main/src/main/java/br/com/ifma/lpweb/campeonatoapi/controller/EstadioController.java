package br.com.ifma.lpweb.campeonatoapi.controller;

import br.com.ifma.lpweb.campeonatoapi.dto.EstadioCreateUpdateDTO;
import br.com.ifma.lpweb.campeonatoapi.dto.EstadioDTO;
import br.com.ifma.lpweb.campeonatoapi.model.Estadio;
import br.com.ifma.lpweb.campeonatoapi.service.EstadioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/estadios")
public class EstadioController {

 @Autowired
 private EstadioService estadioService;

 @Autowired
 private ModelMapper modelMapper;

 @GetMapping
 public ResponseEntity<List<EstadioDTO>> listarTodos() {
     List<Estadio> estadios = estadioService.listarTodos();
     List<EstadioDTO> estadioDTOS = estadios.stream()
             .map(estadio -> modelMapper.map(estadio, EstadioDTO.class))
             .collect(Collectors.toList());
     return ResponseEntity.ok(estadioDTOS);
 }

 @Operation(summary = "Busca um estádio por ID", description = "Retorna os detalhes de um estádio específico.")
 @ApiResponses(value = {
     @ApiResponse(responseCode = "200", description = "Estádio encontrado com sucesso"),
     @ApiResponse(responseCode = "404", description = "Estádio não encontrado para o ID informado")
 })
 @GetMapping("/{id}")
 public ResponseEntity<EstadioDTO> buscarPorId(@PathVariable Integer id) {
     return estadioService.buscarPorId(id)
             .map(estadio -> ResponseEntity.ok(modelMapper.map(estadio, EstadioDTO.class)))
             .orElse(ResponseEntity.notFound().build());
 }

 @PostMapping
 public ResponseEntity<EstadioDTO> criar(@Valid @RequestBody EstadioCreateUpdateDTO estadioDTO) {
     Estadio estadio = modelMapper.map(estadioDTO, Estadio.class);
     Estadio estadioSalvo = estadioService.salvar(estadio);

     URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
             .buildAndExpand(estadioSalvo.getId()).toUri();
     
     return ResponseEntity.created(location).body(modelMapper.map(estadioSalvo, EstadioDTO.class));
 }

 @PutMapping("/{id}")
 public ResponseEntity<EstadioDTO> atualizar(@PathVariable Integer id, @Valid @RequestBody EstadioCreateUpdateDTO estadioDTO) {
     Estadio estadio = modelMapper.map(estadioDTO, Estadio.class);
     Estadio estadioAtualizado = estadioService.atualizar(id, estadio);
     return ResponseEntity.ok(modelMapper.map(estadioAtualizado, EstadioDTO.class));
 }

 @DeleteMapping("/{id}")
 public ResponseEntity<Void> remover(@PathVariable Integer id) {
     estadioService.deletar(id);
     return ResponseEntity.noContent().build();
 }
}