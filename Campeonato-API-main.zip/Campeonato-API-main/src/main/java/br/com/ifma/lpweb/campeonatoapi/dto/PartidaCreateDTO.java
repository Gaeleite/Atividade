package br.com.ifma.lpweb.campeonatoapi.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PartidaCreateDTO {
 @NotNull private LocalDate data;
 @NotNull private Integer campeonatoId;
 @NotNull private Integer timeMandanteId;
 @NotNull private Integer timeVisitanteId;
 @NotNull private Integer estadioId;
}
