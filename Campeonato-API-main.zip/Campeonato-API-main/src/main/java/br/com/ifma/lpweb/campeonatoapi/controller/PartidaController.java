package br.com.ifma.lpweb.campeonatoapi.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.ifma.lpweb.campeonatoapi.dto.PartidaCreateDTO;
import br.com.ifma.lpweb.campeonatoapi.dto.PartidaDTO;
import br.com.ifma.lpweb.campeonatoapi.dto.ResultadoCreateDTO;
import br.com.ifma.lpweb.campeonatoapi.model.Partida;
import br.com.ifma.lpweb.campeonatoapi.service.PartidaService;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/partidas")
public class PartidaController {

 @Autowired private PartidaService partidaService;
 @Autowired private ModelMapper modelMapper;

 @PostMapping
 public ResponseEntity<PartidaDTO> criar(@Valid @RequestBody PartidaCreateDTO dto) {
     Partida partidaSalva = partidaService.salvar(dto);
     return ResponseEntity.ok(convertToDto(partidaSalva));
 }

 @GetMapping("/{id}")
 public ResponseEntity<PartidaDTO> buscarPorId(@PathVariable Integer id) {
     return partidaService.buscarPorId(id)
             .map(partida -> ResponseEntity.ok(convertToDto(partida)))
             .orElse(ResponseEntity.notFound().build());
 }

 @PostMapping("/{id}/resultado")
 public ResponseEntity<PartidaDTO> adicionarResultado(@PathVariable Integer id, @Valid @RequestBody ResultadoCreateDTO dto) {
     Partida partidaComResultado = partidaService.adicionarResultado(id, dto);
     return ResponseEntity.ok(convertToDto(partidaComResultado));
 }

 @GetMapping("/ocorridas")
 public ResponseEntity<List<PartidaDTO>> listarOcorridas() {
     List<PartidaDTO> dtos = partidaService.listarOcorridas().stream()
                               .map(this::convertToDto).collect(Collectors.toList());
     return ResponseEntity.ok(dtos);
 }

 @GetMapping("/nao-ocorridas")
 public ResponseEntity<List<PartidaDTO>> listarNaoOcorridas() {
     List<PartidaDTO> dtos = partidaService.listarNaoOcorridas().stream()
                               .map(this::convertToDto).collect(Collectors.toList());
     return ResponseEntity.ok(dtos);
 }

 private PartidaDTO convertToDto(Partida partida) {
     // Lógica customizada para mapear os campos aninhados corretamente,
     // pois o ModelMapper pode precisar de ajuda com nomes diferentes (ex: nomeCampeonato).
     PartidaDTO dto = modelMapper.map(partida, PartidaDTO.class);
     dto.setNomeCampeonato(partida.getCampeonato().getNome());
     return dto;
 }
}