package br.com.ifma.lpweb.campeonatoapi.dto;

import java.time.LocalDate;

public class JogadorDTO {
 private Integer id;
 private String nome;
 private LocalDate nascimento;
 private Float altura;
 private Integer timeId;
 private String nomeTime;

 // Getters e Setters
 public Integer getId() { return id; }
 public void setId(Integer id) { this.id = id; }
 public String getNome() { return nome; }
 public void setNome(String nome) { this.nome = nome; }
 public LocalDate getNascimento() { return nascimento; }
 public void setNascimento(LocalDate nascimento) { this.nascimento = nascimento; }
 public Float getAltura() { return altura; }
 public void setAltura(Float altura) { this.altura = altura; }
 public Integer getTimeId() { return timeId; }
 public void setTimeId(Integer timeId) { this.timeId = timeId; }
 public String getNomeTime() { return nomeTime; }
 public void setNomeTime(String nomeTime) { this.nomeTime = nomeTime; }
}
