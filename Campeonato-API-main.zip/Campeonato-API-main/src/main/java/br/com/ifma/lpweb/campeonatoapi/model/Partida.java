package br.com.ifma.lpweb.campeonatoapi.model;

import java.time.LocalDate;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Partida {

 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Integer id;

 private LocalDate data;

 @ManyToOne
 @JoinColumn(name = "campeonato_id", nullable = false)
 private Campeonato campeonato;

 @ManyToOne
 @JoinColumn(name = "time_mandante_id", nullable = false)
 private Time timeMandante;

 @ManyToOne
 @JoinColumn(name = "time_visitante_id", nullable = false)
 private Time timeVisitante;

 @ManyToOne
 @JoinColumn(name = "estadio_id", nullable = false)
 private Estadio estadio;

 // CascadeType.ALL garante que o Resultado seja salvo/atualizado/removido junto com a Partida
 @OneToOne(mappedBy = "partida", cascade = CascadeType.ALL, orphanRemoval = true)
 private Resultado resultado;

}
