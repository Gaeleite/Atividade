package br.com.ifma.lpweb.campeonatoapi.controller;

import java.net.URI;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.com.ifma.lpweb.campeonatoapi.dto.CampeonatoCreateDTO;
import br.com.ifma.lpweb.campeonatoapi.dto.CampeonatoDTO;
import br.com.ifma.lpweb.campeonatoapi.dto.TabelaCampeonatoDTO;
import br.com.ifma.lpweb.campeonatoapi.dto.TimeDTO;
import br.com.ifma.lpweb.campeonatoapi.model.Campeonato;
import br.com.ifma.lpweb.campeonatoapi.model.Time;
import br.com.ifma.lpweb.campeonatoapi.service.CampeonatoService;
import jakarta.validation.Valid;


@RestController
@RequestMapping("/campeonatos")
public class CampeonatoController {

 @Autowired
 private CampeonatoService campeonatoService;

 @Autowired
 private ModelMapper modelMapper;

 @PostMapping
 public ResponseEntity<CampeonatoDTO> criar(@Valid @RequestBody CampeonatoCreateDTO dto) {
     Campeonato campeonatoSalvo = campeonatoService.salvar(dto);
     CampeonatoDTO responseDto = modelMapper.map(campeonatoSalvo, CampeonatoDTO.class);
     
     URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
             .buildAndExpand(campeonatoSalvo.getId()).toUri();
     
     return ResponseEntity.created(location).body(responseDto);
 }

 @GetMapping
 public ResponseEntity<List<CampeonatoDTO>> listar() {
     List<Campeonato> campeonatos = campeonatoService.listarTodos();
     List<CampeonatoDTO> dtos = campeonatos.stream()
             .map(c -> modelMapper.map(c, CampeonatoDTO.class))
             .collect(Collectors.toList());
     return ResponseEntity.ok(dtos);
 }

 // Endpoint para a funcionalidade específica 
 @GetMapping("/{id}/times")
 public ResponseEntity<Set<TimeDTO>> listarTimes(@PathVariable Integer id) {
     Set<Time> times = campeonatoService.listarTimesDoCampeonato(id);
     Set<TimeDTO> dtos = times.stream()
             .map(t -> modelMapper.map(t, TimeDTO.class))
             .collect(Collectors.toSet());
     return ResponseEntity.ok(dtos);
 }
 
 @GetMapping("/{id}/tabela")
 public ResponseEntity<List<TabelaCampeonatoDTO>> getTabela(@PathVariable Integer id) {
     List<TabelaCampeonatoDTO> tabela = campeonatoService.gerarTabela(id);
     return ResponseEntity.ok(tabela);
 }
}