package br.com.ifma.lpweb.campeonatoapi.repository;

import br.com.ifma.lpweb.campeonatoapi.model.Jogador;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface JogadorRepository extends JpaRepository<Jogador, Integer> {
 // A implementação da busca paginada [cite: 118] é fornecida pelo JpaRepository (método findAll(Pageable pageable))
}
