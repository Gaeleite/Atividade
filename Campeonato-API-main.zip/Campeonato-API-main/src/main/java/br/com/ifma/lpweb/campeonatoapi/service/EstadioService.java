package br.com.ifma.lpweb.campeonatoapi.service;

import br.com.ifma.lpweb.campeonatoapi.model.Estadio;
import br.com.ifma.lpweb.campeonatoapi.repository.EstadioRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class EstadioService {

 @Autowired
 private EstadioRepository estadioRepository;

 @Transactional(readOnly = true)
 public List<Estadio> listarTodos() {
     return estadioRepository.findAll();
 }

 @Transactional(readOnly = true)
 public Optional<Estadio> buscarPorId(Integer id) {
     return estadioRepository.findById(id);
 }

 @Transactional
 public Estadio salvar(Estadio estadio) {
     // Validação extra para evitar nomes duplicados
     if (estadioRepository.findByNome(estadio.getNome()).isPresent()) {
         throw new IllegalArgumentException("Já existe um estádio com o nome " + estadio.getNome());
     }
     return estadioRepository.save(estadio);
 }

 @Transactional
 public Estadio atualizar(Integer id, Estadio estadioAtualizado) {
     Estadio estadioExistente = estadioRepository.findById(id)
             .orElseThrow(() -> new EntityNotFoundException("Estádio não encontrado com id: " + id));
     
     estadioExistente.setNome(estadioAtualizado.getNome());
     estadioExistente.setEndereco(estadioAtualizado.getEndereco());

     return estadioRepository.save(estadioExistente);
 }

 @Transactional
 public void deletar(Integer id) {
     if (!estadioRepository.existsById(id)) {
         throw new EntityNotFoundException("Estádio não encontrado com id: " + id);
     }
     // Adicionar aqui uma verificação se o estádio está em uso antes de deletar
     estadioRepository.deleteById(id);
 }
}
