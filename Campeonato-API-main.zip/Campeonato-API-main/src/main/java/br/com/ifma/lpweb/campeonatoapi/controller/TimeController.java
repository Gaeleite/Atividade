package br.com.ifma.lpweb.campeonatoapi.controller;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.com.ifma.lpweb.campeonatoapi.dto.TimeCreateDTO;
import br.com.ifma.lpweb.campeonatoapi.dto.TimeDTO;
import br.com.ifma.lpweb.campeonatoapi.model.Time;
import br.com.ifma.lpweb.campeonatoapi.service.TimeService;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/times")
public class TimeController {

 @Autowired
 private TimeService timeService;

 @Autowired
 private ModelMapper modelMapper; // Injete o ModelMapper

 // GET /times
 @GetMapping
 public List<TimeDTO> listarTodos() {
     List<Time> times = timeService.listarTodos();
     return times.stream()
                 .map(time -> modelMapper.map(time, TimeDTO.class))
                 .collect(Collectors.toList());
 }

 // GET /times/{id}
 @GetMapping("/{id}")
 public ResponseEntity<TimeDTO> buscarPorId(@PathVariable Integer id) {
     return timeService.buscarPorId(id)
             .map(time -> ResponseEntity.ok(modelMapper.map(time, TimeDTO.class)))
             .orElse(ResponseEntity.notFound().build());
 }

  @PostMapping
 public ResponseEntity<TimeDTO> criar(@Valid @RequestBody TimeCreateDTO timeCreateDTO) {
     // Passa o DTO diretamente para o serviço
     Time timeSalvo = timeService.salvar(timeCreateDTO);

     URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
             .buildAndExpand(timeSalvo.getId()).toUri();

     // Converte a entidade retornada para o DTO de resposta
     return ResponseEntity.created(location).body(convertToDto(timeSalvo));
 }

 @PutMapping("/{id}")
 public ResponseEntity<TimeDTO> atualizar(@PathVariable Integer id, @Valid @RequestBody TimeCreateDTO timeCreateDTO) {
     // Passa o DTO diretamente para o serviço
     Time timeAtualizado = timeService.atualizar(id, timeCreateDTO);
     return ResponseEntity.ok(convertToDto(timeAtualizado));
 }
 
 @DeleteMapping("/{id}")
 public ResponseEntity<Void> remover(@PathVariable Integer id) {
     timeService.deletar(id);
     return ResponseEntity.noContent().build();
 }
 
 // Método auxiliar para converter Entidade para DTO de resposta
 private TimeDTO convertToDto(Time time) {
     return modelMapper.map(time, TimeDTO.class);
 }
}
