package br.com.ifma.lpweb.campeonatoapi.repository;

import br.com.ifma.lpweb.campeonatoapi.model.Partida;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface PartidaRepository extends JpaRepository<Partida, Integer> {
 
 // Busca partidas cuja data é anterior a hoje (já ocorreram)
 List<Partida> findByDataBefore(LocalDate data);

 // Busca partidas cuja data é hoje ou no futuro (não ocorreram)
 List<Partida> findByDataAfterOrDataEquals(LocalDate data1, LocalDate data2);
 
 // Adicione este método dentro da interface PartidaRepository
 List<Partida> findByCampeonatoIdAndResultadoIsNotNull(Integer campeonatoId);
}
