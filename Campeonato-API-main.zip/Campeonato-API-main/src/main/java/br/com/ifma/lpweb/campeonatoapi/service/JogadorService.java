package br.com.ifma.lpweb.campeonatoapi.service;

import br.com.ifma.lpweb.campeonatoapi.dto.JogadorCreateUpdateDTO;
import br.com.ifma.lpweb.campeonatoapi.model.Jogador;
import br.com.ifma.lpweb.campeonatoapi.model.Time;
import br.com.ifma.lpweb.campeonatoapi.repository.JogadorRepository;
import br.com.ifma.lpweb.campeonatoapi.repository.TimeRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class JogadorService {

 @Autowired
 private JogadorRepository jogadorRepository;

 @Autowired
 private TimeRepository timeRepository;

 @Transactional(readOnly = true)
 public Page<Jogador> listarTodos(Pageable pageable) {
     return jogadorRepository.findAll(pageable);
 }

 @Transactional(readOnly = true)
 public Optional<Jogador> buscarPorId(Integer id) {
     return jogadorRepository.findById(id);
 }

 @Transactional
 public Jogador salvar(JogadorCreateUpdateDTO jogadorDTO) {
     Time time = timeRepository.findById(jogadorDTO.getTimeId())
             .orElseThrow(() -> new EntityNotFoundException("Time não encontrado com id: " + jogadorDTO.getTimeId()));

     Jogador jogador = new Jogador();
     jogador.setNome(jogadorDTO.getNome());
     jogador.setNascimento(jogadorDTO.getNascimento());
     jogador.setAltura(jogadorDTO.getAltura());
     jogador.setGenero(jogadorDTO.getGenero());
     jogador.setTimeEmQueJoga(time);

     return jogadorRepository.save(jogador);
 }

 @Transactional
 public Jogador atualizar(Integer id, JogadorCreateUpdateDTO jogadorDTO) {
     Jogador jogador = jogadorRepository.findById(id)
             .orElseThrow(() -> new EntityNotFoundException("Jogador não encontrado com id: " + id));

     Time time = timeRepository.findById(jogadorDTO.getTimeId())
             .orElseThrow(() -> new EntityNotFoundException("Time não encontrado com id: " + jogadorDTO.getTimeId()));

     jogador.setNome(jogadorDTO.getNome());
     jogador.setNascimento(jogadorDTO.getNascimento());
     jogador.setAltura(jogadorDTO.getAltura());
     jogador.setGenero(jogadorDTO.getGenero());
     jogador.setTimeEmQueJoga(time);

     return jogadorRepository.save(jogador);
 }
 
 @Transactional
 public void deletar(Integer id) {
     if (!jogadorRepository.existsById(id)) {
         throw new EntityNotFoundException("Jogador não encontrado com id: " + id);
     }
     jogadorRepository.deleteById(id);
 }
}
