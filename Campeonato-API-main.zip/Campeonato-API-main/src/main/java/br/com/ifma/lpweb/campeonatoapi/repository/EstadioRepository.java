package br.com.ifma.lpweb.campeonatoapi.repository;

import br.com.ifma.lpweb.campeonatoapi.model.Estadio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface EstadioRepository extends JpaRepository<Estadio, Integer> {
 Optional<Estadio> findByNome(String nome);
}
