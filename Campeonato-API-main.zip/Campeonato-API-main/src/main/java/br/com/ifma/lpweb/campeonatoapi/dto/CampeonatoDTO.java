package br.com.ifma.lpweb.campeonatoapi.dto;

import java.util.Set;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CampeonatoDTO {
 private Integer id;
 private String nome;
 private Integer ano;
 private Set<TimeDTO> times; // Usando o TimeDTO que já deve existir

}