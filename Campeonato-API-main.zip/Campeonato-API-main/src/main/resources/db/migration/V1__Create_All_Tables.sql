-- V1__Create_All_Tables.sql

CREATE TABLE estadio (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL UNIQUE,
    endereco VARCHAR(255) NOT NULL
);

CREATE TABLE time (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL UNIQUE,
    estadio_sede_id INTEGER,
    FOREIGN KEY (estadio_sede_id) REFERENCES estadio(id)
);

CREATE TABLE jogador (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    nascimento DATE NOT NULL,
    genero VARCHAR(50),
    altura FLOAT,
    time_id INTEGER,
    FOREIGN KEY (time_id) REFERENCES time(id)
);

CREATE TABLE campeonato (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    ano INTEGER NOT NULL
);

-- Tabela de junção para a relação Muitos-para-Muitos entre Campeonato e Time
CREATE TABLE campeonato_time (
    campeonato_id INTEGER NOT NULL,
    time_id INTEGER NOT NULL,
    PRIMARY KEY (campeonato_id, time_id),
    FOREIGN KEY (campeonato_id) REFERENCES campeonato(id),
    FOREIGN KEY (time_id) REFERENCES time(id)
);

CREATE TABLE partida (
    id SERIAL PRIMARY KEY,
    data DATE NOT NULL,
    campeonato_id INTEGER NOT NULL,
    time_mandante_id INTEGER NOT NULL,
    time_visitante_id INTEGER NOT NULL,
    estadio_id INTEGER NOT NULL,
    FOREIGN KEY (campeonato_id) REFERENCES campeonato(id),
    FOREIGN KEY (time_mandante_id) REFERENCES time(id),
    FOREIGN KEY (time_visitante_id) REFERENCES time(id),
    FOREIGN KEY (estadio_id) REFERENCES estadio(id)
);

CREATE TABLE resultado (
    id SERIAL PRIMARY KEY,
    num_gols_mandante INTEGER,
    num_gols_visitante INTEGER,
    partida_id INTEGER UNIQUE, -- Um resultado pertence a uma única partida
    FOREIGN KEY (partida_id) REFERENCES partida(id)
);