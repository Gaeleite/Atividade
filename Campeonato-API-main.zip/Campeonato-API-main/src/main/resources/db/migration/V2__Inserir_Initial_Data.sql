-- #################################################
-- ###            CADASTRO DE ESTÁDIOS           ###
-- #################################################
-- IDs: 1-Maracanã, 2-São Januário, 3-Neo Química Arena, 4-Allianz Parque
INSERT INTO estadio (id, nome, endereco) VALUES (1, 'Maracanã', 'Av. Pres. Castelo Branco, Portão 3 - Maracanã, Rio de Janeiro - RJ');
INSERT INTO estadio (id, nome, endereco) VALUES (2, 'São Januário', 'R. Gen. Almério de Moura, 131 - Vasco da Gama, Rio de Janeiro - RJ');
INSERT INTO estadio (id, nome, endereco) VALUES (3, 'Neo Química Arena', 'Av. Miguel Ignácio Curi, 111 - Artur Alvim, São Paulo - SP');
INSERT INTO estadio (id, nome, endereco) VALUES (4, 'Allianz Parque', 'Av. Francisco Matarazzo, 1705 - Água Branca, São Paulo - SP');

-- Altera a sequência do ID para evitar conflitos com futuras inserções pela API
ALTER SEQUENCE estadio_id_seq RESTART WITH 5;


-- #################################################
-- ###              CADASTRO DE TIMES            ###
-- #################################################
-- IDs: 1-Flamengo, 2-Vasco, 3-Corinthians, 4-Palmeiras
INSERT INTO time (id, nome, estadio_sede_id) VALUES (1, 'Flamengo', 1);
INSERT INTO time (id, nome, estadio_sede_id) VALUES (2, 'Vasco da Gama', 2);
INSERT INTO time (id, nome, estadio_sede_id) VALUES (3, 'Corinthians', 3);
INSERT INTO time (id, nome, estadio_sede_id) VALUES (4, 'Palmeiras', 4);

ALTER SEQUENCE time_id_seq RESTART WITH 5;


-- #################################################
-- ###            CADASTRO DE JOGADORES          ###
-- #################################################
-- IDs: 1-Zico, 2-Gabigol, 3-Roberto Dinamite, 4-Juninho, 5-Sócrates, 6-Cássio, 7-Ademir da Guia, 8-Dudu

-- Jogadores do Flamengo (timeId = 1)
INSERT INTO jogador (id, nome, nascimento, altura, genero, time_id) VALUES (1, 'Zico', '1953-03-03', 1.72, 'Masculino', 1);
INSERT INTO jogador (id, nome, nascimento, altura, genero, time_id) VALUES (2, 'Gabriel Barbosa', '1996-08-30', 1.78, 'Masculino', 1);

-- Jogadores do Vasco (timeId = 2)
INSERT INTO jogador (id, nome, nascimento, altura, genero, time_id) VALUES (3, 'Roberto Dinamite', '1954-04-13', 1.86, 'Masculino', 2);
INSERT INTO jogador (id, nome, nascimento, altura, genero, time_id) VALUES (4, 'Juninho Pernambucano', '1975-01-30', 1.78, 'Masculino', 2);

-- Jogadores do Corinthians (timeId = 3)
INSERT INTO jogador (id, nome, nascimento, altura, genero, time_id) VALUES (5, 'Sócrates', '1954-02-19', 1.93, 'Masculino', 3);
INSERT INTO jogador (id, nome, nascimento, altura, genero, time_id) VALUES (6, 'Cássio Ramos', '1987-06-06', 1.96, 'Masculino', 3);

-- Jogadores do Palmeiras (timeId = 4)
INSERT INTO jogador (id, nome, nascimento, altura, genero, time_id) VALUES (7, 'Ademir da Guia', '1942-04-03', 1.80, 'Masculino', 4);
INSERT INTO jogador (id, nome, nascimento, altura, genero, time_id) VALUES (8, 'Dudu', '1992-01-07', 1.66, 'Masculino', 4);

ALTER SEQUENCE jogador_id_seq RESTART WITH 9;

