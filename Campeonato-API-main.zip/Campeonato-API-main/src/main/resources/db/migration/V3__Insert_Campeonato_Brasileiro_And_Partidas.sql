-- #################################################
-- ###      CADASTRO DO CAMPEONATO BRASILEIRO    ###
-- #################################################
-- ID do Campeonato: 1
INSERT INTO campeonato (id, nome, ano) VALUES (1, 'Campeonato Brasileiro', 2025);
ALTER SEQUENCE campeonato_id_seq RESTART WITH 2;


-- #################################################
-- ###  ASSOCIAÇÃO DOS TIMES AO CAMPEONATO (ID=1) ###
-- #################################################
-- Times com IDs 1, 2, 3, 4 que já existem no banco
INSERT INTO campeonato_time (campeonato_id, time_id) VALUES (1, 1); -- Flamengo
INSERT INTO campeonato_time (campeonato_id, time_id) VALUES (1, 2); -- Vasco da Gama
INSERT INTO campeonato_time (campeonato_id, time_id) VALUES (1, 3); -- Corinthians
INSERT INTO campeonato_time (campeonato_id, time_id) VALUES (1, 4); -- Palmeiras


-- #################################################
-- ###           CADASTRO DE PARTIDAS            ###
-- #################################################
-- Partida 1: Flamengo vs Corinthians (Ocorrida)
INSERT INTO partida (id, data, campeonato_id, time_mandante_id, time_visitante_id, estadio_id) VALUES (1, '2025-07-15', 1, 1, 3, 1);

-- Partida 2: Palmeiras vs Vasco (Ocorrida)
INSERT INTO partida (id, data, campeonato_id, time_mandante_id, time_visitante_id, estadio_id) VALUES (2, '2025-07-16', 1, 4, 2, 4);

-- Partida 3: Vasco vs Flamengo (Não Ocorrida)
INSERT INTO partida (id, data, campeonato_id, time_mandante_id, time_visitante_id, estadio_id) VALUES (3, '2025-08-10', 1, 2, 1, 2);

-- Partida 4: Corinthians vs Palmeiras (Ocorrida)
INSERT INTO partida (id, data, campeonato_id, time_mandante_id, time_visitante_id, estadio_id) VALUES (4, '2025-07-20', 1, 3, 4, 3);

-- Partida 5: Vasco vs Corinthians (Ocorrida)
INSERT INTO partida (id, data, campeonato_id, time_mandante_id, time_visitante_id, estadio_id) VALUES (5, '2025-07-22', 1, 2, 3, 2);

-- Partida 6: Palmeiras vs Flamengo (Não Ocorrida)
INSERT INTO partida (id, data, campeonato_id, time_mandante_id, time_visitante_id, estadio_id) VALUES (6, '2025-08-12', 1, 4, 1, 4);

ALTER SEQUENCE partida_id_seq RESTART WITH 7;


-- #################################################
-- ###       CADASTRO DE UM RESULTADO            ###
-- #################################################
-- Resultado para a Partida 1 (Flamengo 3 x 1 Corinthians)
INSERT INTO resultado (id, num_gols_mandante, num_gols_visitante, partida_id) VALUES (1, 3, 1, 1);

-- Adicionando resultado para a Partida 2 (Palmeiras 2 x 0 Vasco), que já existia
INSERT INTO resultado (id, num_gols_mandante, num_gols_visitante, partida_id) VALUES (2, 2, 0, 2);

-- Adicionando resultado para a nova Partida 4 (Corinthians 1 x 1 Palmeiras)
INSERT INTO resultado (id, num_gols_mandante, num_gols_visitante, partida_id) VALUES (3, 1, 1, 4);

-- Adicionando resultado para a nova Partida 5 (Vasco 2 x 1 Corinthians)
INSERT INTO resultado (id, num_gols_mandante, num_gols_visitante, partida_id) VALUES (4, 2, 1, 5);

ALTER SEQUENCE resultado_id_seq RESTART WITH 5;